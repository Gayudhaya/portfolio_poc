# Financial Portfolio Management System

## Setup Instructions

```bash
npm install -g @angular/cli
npm install
ng serve
```

### Features
- Dashboard with interactive charts
- Investment form with validation
- Custom pipes, directives
- Http Interceptor
- Lazy loading
- TypeScript type checks
- Responsive layout

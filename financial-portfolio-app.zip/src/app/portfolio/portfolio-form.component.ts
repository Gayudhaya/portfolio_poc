
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-portfolio-form',
  template: \`
    <form [formGroup]="form" (ngSubmit)="onSubmit()">
      <input formControlName="assetType" placeholder="Asset Type" required />
      <input type="number" formControlName="quantity" placeholder="Quantity" required />
      <input type="number" formControlName="price" placeholder="Price" required />
      <input type="date" formControlName="purchaseDate" required />
      <button type="submit" [disabled]="form.invalid">Submit</button>
    </form>
  \`
})
export class PortfolioFormComponent implements OnInit {
  form: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.form = this.fb.group({
      assetType: ['', Validators.required],
      quantity: ['', [Validators.required, Validators.min(1)]],
      price: ['', [Validators.required, Validators.min(0.01)]],
      purchaseDate: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.form.valid) {
      console.log(this.form.value);
    }
  }
}

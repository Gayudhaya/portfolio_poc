
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class PortfolioService {
  getPortfolioPerformance(): Observable<any> {
    return of({ allocation: [], trends: [], metrics: {} });
  }
}

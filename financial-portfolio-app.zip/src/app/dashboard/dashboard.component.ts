
import { Component } from '@angular/core';
import { PortfolioService } from '../core/portfolio.service';

@Component({
  selector: 'app-dashboard',
  template: '<p>Dashboard with charts here</p>'
})
export class DashboardComponent {
  constructor(private portfolioService: PortfolioService) {}
}
